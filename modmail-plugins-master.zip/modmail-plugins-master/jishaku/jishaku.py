def setup(bot):
    bot.load_extension("jishaku")
